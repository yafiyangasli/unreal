-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2020 at 08:09 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unreal`
--

-- --------------------------------------------------------

--
-- Table structure for table `bukti`
--

CREATE TABLE `bukti` (
  `id_bukti` int(11) NOT NULL,
  `id_checkout` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_akun` varchar(50) NOT NULL,
  `nomor_akun` varchar(50) NOT NULL,
  `bank` varchar(25) NOT NULL,
  `total` int(11) NOT NULL,
  `tanggal_trans` varchar(100) NOT NULL,
  `bukti_trans` varchar(255) NOT NULL,
  `is_processed` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `size` varchar(10) NOT NULL,
  `harga` int(11) NOT NULL,
  `berat` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id_checkout` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `address` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `deadline` varchar(255) NOT NULL,
  `is_upload` int(11) NOT NULL,
  `no_resi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE `header` (
  `tempat` varchar(25) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`tempat`, `gambar`) VALUES
('Home', 'header.png'),
('Lookbook', 'Clothing-Mens-Sweats-And-Hoodies-Header-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `help`
--

CREATE TABLE `help` (
  `id_help` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `pesan` text NOT NULL,
  `waktu` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jenis_produk`
--

CREATE TABLE `jenis_produk` (
  `jenis` varchar(25) NOT NULL,
  `id_jenis` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_produk`
--

INSERT INTO `jenis_produk` (`jenis`, `id_jenis`) VALUES
('Clothes', 'clothes'),
('Floapers', 'floapers'),
('Pants', 'pants'),
('Shoes', 'shoes');

-- --------------------------------------------------------

--
-- Table structure for table `liked_items`
--

CREATE TABLE `liked_items` (
  `username` varchar(128) NOT NULL,
  `id_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lookbook`
--

CREATE TABLE `lookbook` (
  `id_lookbook` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `date` varchar(200) NOT NULL,
  `gambar1` varchar(255) NOT NULL,
  `gambar2` varchar(255) NOT NULL,
  `gambar3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lookbook`
--

INSERT INTO `lookbook` (`id_lookbook`, `nama`, `date`, `gambar1`, `gambar2`, `gambar3`) VALUES
(40, 'Sunny Sides', '13-05-2020', 'jumpman.png', 'supreme.png', 'stussy.png'),
(41, 'Nighty Nide', '06-05-2020', 'trouser-styles-header1.jpg', 'Clothing-Mens-Sweats-And-Hoodies-Header-1.jpg', 'Header2.jpg'),
(42, 'Summer Vibes', '06-05-2020', 'stussy.png', 'Header2.jpg', 'jumpman.png');

-- --------------------------------------------------------

--
-- Table structure for table `navbar`
--

CREATE TABLE `navbar` (
  `id_navbar` int(11) NOT NULL,
  `nama_navbar` varchar(25) NOT NULL,
  `link_navbar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `navbar`
--

INSERT INTO `navbar` (`id_navbar`, `nama_navbar`, `link_navbar`) VALUES
(1, 'NEW PRODUCT', 'home'),
(2, 'LOOKBOOK', 'lookbook'),
(3, 'CATALOGUE', 'catalogue'),
(4, 'LOGIN', 'auth'),
(5, 'HELP', 'help'),
(6, 'ABOUT', 'about'),
(7, 'Cart', 'user/cart'),
(8, 'Saved Items', 'user/favorites');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `id_newsletter` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orderan`
--

CREATE TABLE `orderan` (
  `id_orderan` int(11) NOT NULL,
  `id_checkout` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `size` varchar(10) NOT NULL,
  `harga` int(11) NOT NULL,
  `waktu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(35) NOT NULL,
  `jenis` varchar(25) NOT NULL,
  `harga` int(100) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `gambarlarger` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `berat` float NOT NULL,
  `is_new` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `jenis`, `harga`, `gambar`, `gambarlarger`, `deskripsi`, `berat`, `is_new`) VALUES
(153, 'Baju 1', 'Clothes', 200000, 'plain.png', 'plainlarger.png', 'Playing around with colours, messin\' around with graphics, and always producing high quality dailywear garments that are designed to turn heads and drop panties. Swing by our Jakarta HQ at Jl. Kemang Selatan VIII No. 63/B2, Kemang, South Jakarta. If you\'re too lazy, check us out on the \'Gram @public.culture and follow us.', 0.25, 1),
(154, 'Baju 2', 'Clothes', 250000, 'plain.png', 'plainlarger.png', 'Playing around with colours, messin\' around with graphics, and always producing high quality dailywear garments that are designed to turn heads and drop panties. Swing by our Jakarta HQ at Jl. Kemang Selatan VIII No. 63/B2, Kemang, South Jakarta. If you\'re too lazy, check us out on the \'Gram @public.culture and follow us.', 0.25, 0),
(157, 'Baju 3', 'Clothes', 350000, 'plain.png', 'plainlarger.png', 'anjay mabar banget', 0.25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `produk_lookbook`
--

CREATE TABLE `produk_lookbook` (
  `id_lookbook` int(11) NOT NULL,
  `nama_produk_lookbook` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk_lookbook`
--

INSERT INTO `produk_lookbook` (`id_lookbook`, `nama_produk_lookbook`) VALUES
(40, 'Baju 1'),
(40, 'Baju 2'),
(40, 'Baju 3'),
(41, 'Baju 1'),
(41, 'Baju 2'),
(41, 'Celana 1'),
(42, 'Baju 1'),
(42, 'Baju 2'),
(42, 'Celana 1');

-- --------------------------------------------------------

--
-- Table structure for table `sizestok`
--

CREATE TABLE `sizestok` (
  `id_produk` int(11) NOT NULL,
  `size` varchar(10) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sizestok`
--

INSERT INTO `sizestok` (`id_produk`, `size`, `stok`) VALUES
(153, 'L', 1),
(153, 'M', 13),
(154, 'M', 6),
(156, 'L', 49),
(157, 'M', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `role_id` int(1) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `name`, `email`, `password`, `telephone`, `address`, `role_id`, `is_active`) VALUES
('admin', '', 'admin@gmail.com', '$2y$10$NXyzLnBFv79tAgRGZGDZauuIFIkhLutLcQDtdqfCInXd5UAmR0VFS', '', '', 1, 1),
('ayamgeprek', 'Ayam Geprek Buto Ijo', 'geprek@gmail.com', '$2y$10$40Snd0Ld1XGJK.vzNSmMoO7w7OkE8xNPWR7sL.5tuHiaactdc61nq', '089503924256', 'Geprek Unila', 2, 1),
('ayamgeprek123', 'Yafi', 'yafi0721@gmail.com', '$2y$10$EW5W8tjvzt1lwILIedxiJu77aQhMFEjzg6lSIwa.HqPZr53op5vw6', '089503924256', 'Jl. Perintis Kemerdekaan No. 63, Tanjung Gading', 2, 1),
('geprekijoijo', 'geprek ijo', 'geprek123@gmail.com', '$2y$10$ZXzTADI.1neXAbzC4U1eyuJLjb.tA4d4QmA66GzRDZRTJK0SuYQPS', '089503925252', 'Jl. Geprek No. 63, Bandarlampung\r\n', 2, 1),
('gepreksambel', 'geprek sambel', 'sambel@gmail.com', '$2y$10$evl0aLS4HpcK4Cyda/StROHvM8P1mOVuo8SK3Hx18dHVMj/lTFO7W', '089503925252', 'Jl. Geprek No,63', 2, 1),
('jerukbali', '', 'jeruk@gmail.com', '$2y$10$lVpMM2fw6E4O7r7XZ35A/un3/sDLfqObprLTMuLDjlBJBXC52cle6', '081554387248', 'Jl. Jeruk banget', 2, 1),
('milosaurus', '', 'milo@gmail.com', '$2y$10$mC43Zfo2NUUTDz4p86Ydgupy6V24.ejYB6ChVqKLnyekSXGnbNM42', '089503924256', '', 2, 1),
('yafifahmi', 'Yafi Fahmi', 'yafi@gmail.com', '$2y$10$BXjPlFGGCybplGWRMvX7k.UZrWJ7CyujEp.UgwHnEF9FtJW8R7tIS', '089503924256', 'Jl. Perintis Kemerdekaan no. 63', 2, 1),
('yafiyafi', 'Yafi', 'yafi1234@gmail.com', '$2y$10$8BGYiG9n6OIkB3AqJGlcoe6HEsn46z4Y6w95hkRsqNfCvwLu1ZoHm', '089503924256', 'Bandarlampung', 2, 1),
('yafiyangasli', 'Yafi Fahmi', 'yafi123@gmail.com', '$2y$10$AwcbI9md22g5bNRtiNJTZ.WvfMCCyLk8QdVTAFW2XC1o0bje1qW5q', '089503925252', 'Jl. Perintis Kemerdekaan No. 23', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bukti`
--
ALTER TABLE `bukti`
  ADD PRIMARY KEY (`id_bukti`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id_checkout`,`username`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`tempat`);

--
-- Indexes for table `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`id_help`);

--
-- Indexes for table `jenis_produk`
--
ALTER TABLE `jenis_produk`
  ADD PRIMARY KEY (`jenis`);

--
-- Indexes for table `liked_items`
--
ALTER TABLE `liked_items`
  ADD PRIMARY KEY (`username`,`id_produk`);

--
-- Indexes for table `lookbook`
--
ALTER TABLE `lookbook`
  ADD PRIMARY KEY (`id_lookbook`);

--
-- Indexes for table `navbar`
--
ALTER TABLE `navbar`
  ADD PRIMARY KEY (`id_navbar`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id_newsletter`);

--
-- Indexes for table `orderan`
--
ALTER TABLE `orderan`
  ADD PRIMARY KEY (`id_orderan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk_lookbook`
--
ALTER TABLE `produk_lookbook`
  ADD PRIMARY KEY (`id_lookbook`,`nama_produk_lookbook`);

--
-- Indexes for table `sizestok`
--
ALTER TABLE `sizestok`
  ADD PRIMARY KEY (`id_produk`,`size`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bukti`
--
ALTER TABLE `bukti`
  MODIFY `id_bukti` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id_checkout` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `help`
--
ALTER TABLE `help`
  MODIFY `id_help` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lookbook`
--
ALTER TABLE `lookbook`
  MODIFY `id_lookbook` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `navbar`
--
ALTER TABLE `navbar`
  MODIFY `id_navbar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id_newsletter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `orderan`
--
ALTER TABLE `orderan`
  MODIFY `id_orderan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
