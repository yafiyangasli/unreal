<div class="row no-gutters">
  <div class="col-md">
  <div class="img-wrapper">
     <img class="img-fluid" src="<?=base_url('assets/img/header/').$header['gambar'];?>">
 </div>
 </div>
</div>

<div class="container">
	<div class="row justify-content-center mt-4">
		<h5>New Arrivals</h5>
	</div>
</div>

<div class="container">
<div class="row justify-content-center">
	<nav class="navbar navbar-expand navbar-light" style="background-color: white; padding-top: 20px; padding-bottom: 20px;">
	    <div class="col">
	    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#newArival" aria-controls="newArival" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	   

	    <div class="collapse navbar-collapse" id="newArival" style="font-size: 14px;">
	      <ul class="navbar-nav">
	      	<li class="nav-item">
	          <a class="nav-link" href="#">New</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Men</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Women</a>
	        </li>
	      </ul>
	      </div>
	  </div>
	  </nav>
  </div>
  
  <div class="row justify-content-center">
  	<div class="col-12 col-md-10 mb-5">
  		<div class="row justify-content-center">  		
  		<?php foreach($newproduk as $pr):?>
  		<div class="card m-3" style="width:11rem; border: none;">
		   <a href="<?=base_url('catalogue/detailProduk/').$pr['id'];?>" class="text-dark text-decoration-none"><img class="card-img-top" src="<?php echo base_url();?>assets/img/produk/<?php echo $pr['gambar'];?>" alt="Card image"></a>
		   <div class="card-body">
		     <a href="<?=base_url('catalogue/detailProduk/').$pr['id'];?>" class="text-dark text-decoration-none"><h6 class="card-title"><?= $pr['nama_produk']?></h6></a>
		     <p class="card-text" style="font-size: 11px;"><?=rupiah($pr['harga'])?></p>
		   </div>
		</div>
		<?php endforeach;?>
		</div>
	</div>
	</div>
</div>