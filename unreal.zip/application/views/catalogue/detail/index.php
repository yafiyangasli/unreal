<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/product.css');?>"media="all"/>
<div class="layout">
    <div class="pname">
        <div class="row-justify-center">
            <h1 class="pb-3"><?=$dproduk['nama_produk']?></h1>
        </div>
    </div>

    <form method="post" action="<?=base_url('user/addToCart/').$dproduk['id'];?>">
    <div class="row no-gutters">
        <div class="col-6 offset-sm-1 offset-md-1 col-sm-5 col-md-5 d-none d-sm-block">
            <img class="img-fluid" name="gambar"  id="gambarDetail" src="<?php echo base_url();?>assets/img/produk/<?php echo $dproduk['gambar'];?>" data-zoom-image="<?php echo base_url();?>assets/img/produk/<?php echo $dproduk['gambarlarger'];?>" style="max-width: 500px; min-width: 250px;">
        </div>
        <div class="col-10 offset-sm-1 offset-md-1 col-sm-5 col-md-5 d-block d-sm-none">
            <img class="img-fluid" name="gambar"  id="gambarDetail2" src="<?php echo base_url();?>assets/img/produk/<?php echo $dproduk['gambar'];?>" data-zoom-image="<?php echo base_url();?>assets/img/produk/<?php echo $dproduk['gambarlarger'];?>" style="max-width: 350px;">
        </div>
    
        <div class="col-12 col-sm-6 col-md offset-md-1">
            <div class="row no-gutters mt-3 mb-4">
                <div class="detail col-12 col-sm-8 text-sm">
                        <?= $this->session->flashdata('message');?>
                    </div>
                <div class="detail col-8 offset-1 col-sm-5 offset-sm-0 col-md-5 mb-3 align-self-center">
                    <h3> <?=rupiah($dproduk['harga'])?></h3>
                </div>
                <?php if($this->session->userdata('username')!=NULL):?>
                <?php if($liked==NULL):?>
                    <div class="detail col-11 offset-1 col-sm-4">
                        <a href="<?=base_url('user/addfav/').$dproduk['id'];?>" class="btn btn-outline-dark"><span><i class="fa fa-fw fa-heart"></i> Add to Wishlist</span></a>
                    </div>
                <?php else:?>
                    <div class="detail col-11 offset-1 col-sm-4">
                        <a href="<?=base_url('user/addfav/').$dproduk['id'];?>" class="btn btn-outline-dark"><span><i class="fa fa-fw fa-times"></i> Remove from Wishlist</span></a>
                    </div>
                <?php endif;?>
                <?php else:?>
                    <div class="detail col-11 offset-1 col-sm-4">
                        <a href="<?=base_url('user/addfav/').$dproduk['id'];?>" class="btn btn-outline-dark"><span><i class="fa fa-fw fa-heart"></i> Add to Wishlist</span></a>
                    </div>
            <?php endif;?>
            </div>
            <div class="row no-gutters col-10">
                <div class="detail col-5 col-sm-3 col-md-3">
                    <div class="form-group">
                        <h4><label for="size">Size</label></h4>
                            <select class="custom-select" name="size" id="size" onChange="getStok()">
                                <option></option>
                                <?php foreach($sizestok as $ss):?>
                                    <?php if($ss['stok']>0):?>
                                    <option value="<?=$ss['size'];?>"><?=$ss['size'];?></option>
                                <?php endif;?>
                                <?php endforeach;?>
                            </select>
                    </div>
                </div>
                <div class="detail col-6 offset-1 col-sm-3 col-md-3 offset-sm-1 offset-md-2">
                    <div class="form-group">
                        <h4><label for="qty">Quantity</label></h4>
                        <select class="custom-select" name="jumlah" id="jumlah">
                            
                        </select>
                    </div>
                </div>
            </div>
            <div class="detail col-12 col-sm-10 col-md-10">
                <h4 class="mt-2">Description</h4>
                <p class="mt-1"><?=$dproduk['deskripsi']?></p>
            </div>
            <div class="detail col-12 col-sm-8 col-md-8 row-justify-center mt-4">
                <button class="cart-button" type="submit">Add to Cart</button>
            </div>
        </div>
    </div>
    </form>
</div>

<script type="text/javascript">
    $('#gambarDetail').elevateZoom({
      zoomType: "inner",
      responsive: true,
      cursor: "crosshair",
      zoomWindowFadeIn: 100,
      zoomWindowFadeOut: 250
         }); 
    $('#gambarDetail2').elevateZoom({
      zoomType: "inner",
      responsive: true,
      cursor: "crosshair",
      zoomWindowFadeIn: 100,
      zoomWindowFadeOut: 250
         });

    function getStok(){
        let size = $('#size').val();
        let id_produk = <?= $dproduk['id']?>;

        $.ajax({
            url: '<?= base_url('catalogue/get_stok/')?>'+`${id_produk}/${size}`,
            dataType: 'json',

            success: function(response){
                var html = '';
                var i;
                for (var i =0; i<response.length; i++) {
                    var a = response[i].stok;
                    for (var j = 1; j<=a ; j++) {
                        html+= '<option value="'+j+'">'+j+'</option>'
                    }
                }
                $('#jumlah').html(html);
            }
        });
    }

</script>