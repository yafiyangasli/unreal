        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?=$title?></h1>

          <div class="row mx-auto mt-5">
          	<div class="col-md-5">
          		<img name="gambar"  id="gambar" src="<?php echo base_url();?>assets/img/produk/<?php echo $produk['gambar'];?>" style="width: 275px">
          	</div>

          	<div class="col-md-5">
          		<h2 class="text-dark"><strong><?= $produk['nama_produk'];?></strong></h2>
          		<h5><?=$produk['jenis']?></h5>
          		<div class="row">
          		<div class="col-sm-4">
          		<p><?=rupiah($produk['harga']);?></p>
          		</div>
          		<div class="col-sm-6">
              <select class="form-control">
                <option>Size - Stock</option>
          		<?php foreach($sizestok as $ss):?>
                <option><?=$ss['size']?> - <?=$ss['stok']?></option>
              <?php endforeach;?>
          		</select>
              </div>
          		</div>
          		<br>
          		<h3 class="text-dark">Description</h3>
          		<p><?=$produk['deskripsi'];?></p>
          	</div>
          	
          </div>
          <?php if($produk['is_new']==0):?>
          <div class="row justify-content-center mt-5 mb-5">
            <div class="col-md-4">
              <a href="<?=base_url('admin/addNewProduk/').$produk['id'];?>" class="btn btn-secondary">Add to New Product</a>
            </div>
          </div>
        <?php endif;?>
            

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->