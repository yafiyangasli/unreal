<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/about.css');?>"media="all"/>
<div class="container">
	<div class="col-12 col-sm col-md align-self-center">
		<div id="wrapper">	
		<h1>About Us</h1>
		<p><strong>UNREAL CLUBS</strong> is a brand and a lifestyle retail store based in Bandar Lampung.</p>
		<p>Started in 2018 as an online store, we expanding our business in mid 2019 with opening our flagship store.
			<br>Our aim is to become a purveyor of a curated multi-brand clothing, accessories and sneakers.</p>
		<p>As a brand and as a store remains unique in its brand identity, its culture, its level of service and
			<br>as a space men and women can both find the best of a worldwide curated selection of goods.</p>
		</div>
	</div>
</div>