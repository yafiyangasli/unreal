<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		if($this->input->post('search')){
			$search=$this->input->post('search');
			$this->session->set_userdata('search',$search);
			redirect('catalogue');
		}
		date_default_timezone_set('Asia/Jakarta');

		$data['checkout']=$this->db->get_where('checkout')->result_array();
		$data['order']=$this->db->get_where('orderan')->result_array();
		$waktuNow=date('Y-m-d H:i:s');
		

		foreach ($data['checkout'] as $ck) {
			if($waktuNow>=$ck['deadline'] && $ck['is_upload']==0){
				foreach($data['order']as$or){
					$idcheckout=$ck['id_checkout'];
					if ($idcheckout == $or['id_checkout']) {
						$item=$or['jumlah'];
						$idproduk=$or['id_produk'];
						$size=$or['size'];

						$selectStok="SELECT * FROM sizestok WHERE id_produk = $idproduk AND size = '$size'";
						$data['sizestok']=$this->db->query($selectStok)->row_array();

						$stok=$data['sizestok']['stok'];
						$kurangStok=$stok+$item;
						
						$this->db->set('stok',$kurangStok);
						$this->db->where('id_produk',$idproduk);
						$this->db->where('size',$size);
						$this->db->update('sizestok');
					}
				}
			    $this->Model->hapusPembelian($ck['id_checkout']);
			    $this->Model->hapusOrderan($ck['id_checkout']);
			}
		}
	}

	public function index()
	{
		$data['active']='LOGIN';
		$data['nav']=$this->db->get('navbar')->result_array();
		$this->form_validation->set_rules('id','Username or Email','required|trim');
		$this->form_validation->set_rules('password','Password','required|trim');

		if($this->form_validation->run()==false){
		$data['title']='Login ';

		$this->load->view('templates/header',$data);
		$this->load->view('auth/index',$data);
		$this->load->view('templates/footer');
		}else{
			
			$this->login();
		}
	}

	public function login(){
		$id=$this->input->post('id');
		$password=$this->input->post('password');

		$user=$this->db->get_where('user',['username'=>$id])->row_array();
		$email=$this->db->get_where('user',['email'=>$id])->row_array();
		if($user){
			//kalo user active
			if($user['is_active']==1){
				if(password_verify($password, $user['password'])){
					$data=[
						'username'=>$user['username'],
						'nama'=>$user['nama'],
						'role_id'=>$user['role_id']
					];
					$this->session->set_userdata($data);
					if($user['role_id']==1){
						redirect('admin');
					}else{
					redirect('home');
				}
				}else{
					$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Wrong password!</div>');
					redirect('auth');
				}
			}else{
				$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Account has not been activated. Please activated first!</div>');
			redirect('auth');
			}
		}if($email){
			//kalo user active
			if($email['is_active']==1){
				if(password_verify($password, $email['password'])){
					$data=[
						'username'=>$email['username'],
						'nama'=>$email['nama'],
						'role_id'=>$email['role_id']
					];
					$this->session->set_userdata($data);
					if($email['role_id']==1){
						redirect('admin');
					}else{
					redirect('home');
				}
				}else{
					$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Wrong password!</div>');
					redirect('auth');
				}
			}else{
				$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Account has not been activated. Please activated first!</div>');
			redirect('auth');
			}
		}else{
			$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Username or Email is not registered!</div>');
			redirect('auth');
		}
	}


	public function logout(){
		$this->session->unset_userdata('username');

		redirect('home');
	}

	public function register(){
		is_maintenance();
		$data['active']='LOGIN';
		$data['nav']=$this->db->get('navbar')->result_array();

		$this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[user.username]',[
			'is_unique' => 'This username has already registered!']);
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]',[
			'is_unique' => 'This email has already registered!']
		);
		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[8]',[
			'min_length'=>'Password to short'
		]);

		$this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]',['matches'=>'Password dont match']);
		$this->form_validation->set_rules('telephone', 'Contact Number', 'required|trim|numeric|min_length[6]',['min_length'=>'Please enter the correct number phone']);
		$this->form_validation->set_rules('terms', 'Terms & Condition', 'required',['required'=>'Please accept our terms and conditions & privacy policy!']);


		if($this->form_validation->run()==false){
		$data['title']='Registration ';
		$this->load->view('templates/header',$data);
		$this->load->view('auth/register');
		$this->load->view('templates/footer');
		}else{
			if ($this->input->post('address')==NULL) {
				$data=[
				'username'=>htmlspecialchars($this->input->post('username',true)),
				'email'=>htmlspecialchars($this->input->post('email',true)),
				'password'=>password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
				'telephone'=>$this->input->post('telephone'),
				'address'=>"",
				'role_id'=>2,
				'is_active'=>1
			];
			}else{
				$data=[
					'username'=>htmlspecialchars($this->input->post('username',true)),
					'email'=>htmlspecialchars($this->input->post('email',true)),
					'password'=>password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
					'telephone'=>$this->input->post('telephone'),
					'address'=>$this->input->post('address'),
					'role_id'=>2,
					'is_active'=>1
				];
			}
			$this->db->insert('user',$data);
			$this->session->set_userdata($data);
			$this->session->set_flashdata('message','<div class="alert alert-light" role="alert">Your registration was successful</div>');
			redirect('user');			
		}	
	}

	public function errors(){
		$this->load->view('auth/error');
	}
}